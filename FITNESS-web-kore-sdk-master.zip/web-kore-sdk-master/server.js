var path = require("path");
var express = require("express");
var app = require("express")();
var jwtlib = require("jsonwebtoken");
const { MongoClient } = require('mongodb');
const bcrypt = require('bcrypt');
// const { JWT_SECRET } = require('dotenv').config().parsed;
const cors = require('cors');
async function connectToMongoDB() {
    const client = new MongoClient('mongodb://127.0.0.1:27017');
    await client.connect();
    return client.db('chatbot');
}
const  JWT_SECRET  = "123";
const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());

var port = 8080;
var gmail=null

var PROJECT_DIR = path.normalize(__dirname);
app.use(express.static(path.join(__dirname, 'public')));
app.use("/", express.static(path.join(PROJECT_DIR, "")));






app.post("/signup", async (req, res) => {
    const { username, password , email } = req.body;
    // console.log(email);
  
    try {
      const db = await connectToMongoDB();
      const usersCollection = db.collection('users');
  
      // Check if the user already exists with the same username
      const existingUser = await usersCollection.findOne({ email });
      console.log("exe",existingUser);
  
      if (existingUser) {
        return res.status(409).json({ message: 'User with this email already exists' });
      }
  
      // Hash the user's password
      const hashedPassword = await bcrypt.hash(password, 10);
  
      // Create a new user document
      const newUser = {
        username,
        password: hashedPassword,
        email
        // Add other user data as needed
      };
  
      // Insert the new user into the collection
      const result = await usersCollection.insertOne(newUser);
      gmail=email;
      console.log("usercreation",result);
      if (result.acknowledged) {
        const payload = {
            user: {
              username: username,
            },
          };
        jwtlib.sign(payload, JWT_SECRET, { expiresIn: '1h' }, (error, token) => {
            if (error) throw error;
      
            const userInfo = {
              username: username,
              email : email
            };
            res.json({ token, userInfo });
          });
      } else{
  res.status(500).json({ message: 'User creation failed' });
      }
    } catch (error) {
      console.error('User creation error:', error);
      res.status(500).json({ message: 'Server error' });
    }
});
  

app.post("/signin", async (req, res) => {
        const { username, password  } = req.body;
      
        try {
          const db = await connectToMongoDB();
          const usersCollection = db.collection('users');
      
          // Find the user by username
          console.log(username,password);
          const user = await usersCollection.findOne({ username });
          console.log("found",user);
      
          if (!user) {
            return res.status(404).json({ message: 'User not found' });
          }
      
          const isMatch = await bcrypt.compare(password, user.password);
          console.log("match",isMatch);
      
          if (!isMatch) {
            return res.status(401).json({ message: 'Invalid credentials' });
          }
          gmail=user.email;
          const payload = {
            user: {
              id: user._id,
              username: user.username,
              email : user.email
            },
          };
      
          jwtlib.sign(payload, JWT_SECRET, { expiresIn: '1h' }, (error, token) => {
            if (error) throw error;
            delete user.password;
      
            const userInfo = {
              id: user._id,
              username: user.username,
              email : user.email
            };
            
            console.log("userInfo",user.email);
            console.log("userInfo sent");
            res.json({ token, userInfo });
          });
        } catch (error) {
          console.error('Authentication error:', error);
          res.status(500).json({ message: 'Server error' });
        }
      });

function generateJWTForOTTBot() { 
  const payload = {
    iat: new Date().getTime() / 1000,
    exp: new Date().getTime() / 1000 + 86400,
    aud: "https://idproxy.kore.ai/authorize",
    iss: "cs-f5dc5627-a422-569b-954b-86dd5bdbbaea",
    sub: `${gmail}` || localStorage.getItem("email")
  };
//   console.log("generateJWTForOTTBot", payload);
  const secret = "WB0iLTGDkhfIquNQXcJENdNv0yN8KcZEBrJPJdva/lI=";

  var token = jwtlib.sign(payload, secret);
  return token;
}

// Bot ID st-dfb655cc-486e-566e-9e5c-02af9e648196
//Client ID cs-e215664a-08e0-58e8-b2cd-257cc4518951
//Client Secret QNcFnZhPd+0QF50vb201+v2wuA+a/KDmSqxnYaEm6Zc=

app.get("/sts", (req, res) => {
  res.set({
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "*",
    "Access-Control-Allow-methods": "*",
  });
  const jwt = generateJWTForOTTBot();
  data = { jwt: jwt };
  res.send(JSON.stringify(data));
});

app.listen(port, function () {
  console.log(
    "Sample Application runnning at http://localhost:" + port ,
  );
});