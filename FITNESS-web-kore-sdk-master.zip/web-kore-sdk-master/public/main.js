var submit = document.querySelector('.enter');
var signup = document.querySelector('#singup1');
var signin = document.querySelector('#signin1');

var email = document.querySelector('#inputBox1');
var nameRegex= /^[a-zA-Z0-9_]{3,20}$/
var passwordRegex= /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)(?!.*\s).{8,}$ /
var emailRegex= /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/

window.onload = function() {
    var active = localStorage.getItem('active');
if(active == "yes") {
    window.location.href="../UI/index_widgets_chat.html";
}else{
    localStorage.setItem("active","no");
}
};

let toLog = false;
// submit.addEventListener('click', function(event) {
//     event.preventDefault(); // Prevent the default form submission
//     console.log('Entered login ', username.value, password.value);
// });

signup.addEventListener('click', () => {
    toLog = false;
    signup.classList.value = "selected";
    signin.classList.value = "";
    email.classList.value = "";
});

signin.addEventListener('click', () => {
    toLog = true;
    signup.classList.value = "";
    signin.classList.value = "selected";
    email.classList.value="hide";
});


submit.addEventListener('click', (event)=>{
    event.preventDefault();
    var username = document.querySelector('.username');
var password = document.querySelector('.password');
var emailid = document.querySelector('#emailid');

// if(nameRegex.test(username) || passwordRegex.test(password) || emailRegex.test(emailid)){
// alert('Please enter correct username and password and email address');
// return;
// }
    
    console.log(username.value, password.value);
    if(toLog==false){
        
        const body ={
            username : username.value,
            password : password.value,
            email : emailid.value
        }
        username.value="";
        password.value="";
        emailid.value="";
        fetch("/signup", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(body),
        })
        .then(response => {
            if(response.status == 409){
                alert("User already exists");
                throw new Error("User already exists");
            }
            if(response.status == 500){
                alert("creation failed");
                throw new Error("creation failed");
            }
            return response.json();
        })
        .then(data => {
            localStorage.setItem("active","yes");
            localStorage.setItem("email",data.userInfo.email);
            // data.token.save();
            alert("Registered sucessfully and moving into ur account");
            window.location.href="../UI/index_widgets_chat.html";
        })
        .catch(error => {
            // alert("error");
            console.error("Error:", error);
        });

    }
    else{
        console.log("Server response");
        const body ={
            username : username.value,
            password : password.value
        }
        username.value="";
        password.value="";
    fetch("/signin", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
    })
    .then(response => {
       
        if(response.status == 404){
            alert("User not found");
            throw new Error("User not found");
        }
        if(response.status == 401){
            alert("Invalid username or password");
            throw new Error("Invalid username or password");
        }
        return response.json();
    })
    .then(data => {
        localStorage.setItem("active","yes");
        localStorage.setItem("email",data.userInfo.email);
        // data.token.save();
        
        window.location.href="../UI/index_widgets_chat.html";
        console.log("Server response:", data.token);
    })
    .catch(error => {
        alert("error");
        console.error("Error:", error);
    });
}

})